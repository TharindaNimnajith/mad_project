package com.example.e_breadshop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button mreg;
    private Button signupbtn;
    private Button cprofile;
    private Button contact;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mreg = findViewById(R.id.reg);

        signupbtn = findViewById(R.id.signup);

        cprofile = findViewById(R.id.customerprofile);

        contact = findViewById(R.id.contactus);



    }

    public void mregister(View v){
        Intent intent = new Intent(MainActivity.this, CustomerRegisterActivity.class );
        startActivity(intent);
    }
    public void clickSignin(View v){
        Intent intent = new Intent(MainActivity.this, Activity1.class );
        startActivity(intent);
    }

    public void clickCprofile(View v){
        Intent intent = new Intent(MainActivity.this, CustomerProfileActivity.class);
        startActivity(intent);
    }
    public void clickcontactus(View v){
        Intent intent = new Intent(MainActivity.this, ContactUsActivity.class);
        startActivity(intent);
    }



}
