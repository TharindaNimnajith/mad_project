package com.example.e_breadshop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CustomerProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_profile);
    }
}
